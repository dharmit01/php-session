# JavaScript Practicals

## Practical 1 : Scientific Calculator

## Description
* A Scientific Calculator made using HTML5, CSS3 and JavaScript. It comprises of most of the Mathematical Functions as well as the Trigonometric Functions. The calculator can be used by mouse clicks as well as can be used using keyboard keys.

## Installation

1. Install VS Code (https://code.visualstudio.com)
2. Install "Live Server" Extension for VSCode using Extension Market Place or
 Launch VS Code Quick Open (Ctrl+P), paste the following command, and press enter.

```
ext install ritwickdey.LiveServer
```
3. Clone the Repo
```
git clone https://github.com/your_username_/Project-Name.git
```
4. Open the project and click on Go Live from the status bar to turn the server on/off.
![go-live](./JSPractical1/images/screenshots/liveserver.jpg)


## Demo Practical 1
![demo](./JSPractical1/images/screenshots/demo.gif)
