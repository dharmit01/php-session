
// Select Elements
const inputElement = document.querySelector('.btns');
const outputOperatorElement = document.querySelector("#expression");
const OutputResultElement = document.querySelector("#resultText");

// Variables for Operators, power function and factorial functions
const operators = ["+", "-", "*", "/"];
const power = "POWER(";
const fact = "FACTORIAL(";

// Defining data object with operations and formula
// Operation will be visible to User
// Formula will be used to calculate
let data = {
    operation: [],
    formula: []
}
let ans = 0;
let result = 0;

// Setting Stored Value in Local Storage to Zero
localStorage.setItem("storedValue", JSON.stringify([0]));

let calculatorButtons = [
    {
        name: "rad",
        symbol: "Rad",
        formula: false,
        type: "key",
        keyboard : ""
    },
    {
        name: "deg",
        symbol: "Deg",
        formula: false,
        type: "key",
        keyboard : 'd'
    },
    {
        name: "square-root",
        symbol: "√",
        formula: "Math.sqrt",
        type: "math_function",
        keyboard : "r"
    },
    {
        name: "cube-root",
        symbol: "3√",
        formula: "Math.cbrt",
        type: "math_function",
        keyboard : ""
    },
    {
        name: "square",
        symbol: "x²",
        formula: power,
        type: "math_function",
    },
    {
        name: "open-parenthesis",
        symbol: "(",
        formula: "(",
        type: "number",
        keyboard : "("
    },
    {
        name: "close-parenthesis",
        symbol: ")",
        formula: ")",
        type: "number",
        keyboard : ")"
    },
    {
        name: "clear",
        symbol: "C",
        formula: false,
        type: "key",
        keyboard : "Escape"
    },
    {
        name: "delete",
        symbol: "⌫",
        formula: false,
        type: "key",
        keyboard : "Backspace"
    },
    {
        name: "pi",
        symbol: "π",
        formula: "Math.PI",
        type: "number",
        keyboard : "p"
    },
    {
        name: "sin",
        symbol: "sin",
        formula: "trigo(Math.sin,",
        type: "trigo_function",
        keyboard : "s"
    },
    {
        name: "cos",
        symbol: "cos",
        formula: "trigo(Math.cos,",
        type: "trigo_function",
        keyboard : "c"
    },
    {
        name: "tan",
        symbol: "tan",
        formula: "trigo(Math.tan,",
        type: "trigo_function",
        keyboard : "t"
    },
    {
        name: "cosec",
        symbol: "cosec",
        formula: "1/trigo(Math.sin,",
        type: "trigo_function",
        keyboard : ""
    },
    {
        name: "sec",
        symbol: "sec",
        formula: "1/trigo(Math.cos,",
        type: "trigo_function",
        keyboard : ""
    },
    {
        name: "cot",
        symbol: "cot",
        formula: "1/trigo(Math.tan,",
        type: "trigo_function",
        keyboard : ""
    },
    {
        name: "asin",
        symbol: "asin",
        formula: "inverseTrigo(Math.asin,",
        type: "trigo_function",
        keyboard : ""
    },
    {
        name: "acos",
        symbol: "acos",
        formula: "inverseTrigo(Math.acos,",
        type: "trigo_function",
        keyboard : ""
    },
    {
        name: "atan",
        symbol: "atan",
        formula: "inverseTrigo(Math.atan,",
        type: "trigo_function",
        keyboard : ""
    },
    {
        name: "acosec",
        symbol: "acosec",
        formula: "inverseTrigo(Math.asin,1/",
        type: "trigo_function",
        keyboard : ""
    },
    {
        name: "asec",
        symbol: "asec",
        formula: "inverseTrigo(Math.acos,1/",
        type: "trigo_function",
        keyboard : ""
    },
    {
        name: "acot",
        symbol: "acot",
        formula: "inverseTrigo(Math.atan,1/",
        type: "trigo_function",
        keyboard : ""
    },
    {
        name: "sinh",
        symbol: "sinh",
        formula: "trigo(Math.sinh,",
        type: "trigo_function",
        keyboard : ""
    },
    {
        name: "cosh",
        symbol: "cosh",
        formula: "trigo(Math.cosh,",
        type: "trigo_function",
        keyboard : ""
    },
    {
        name: "tanh",
        symbol: "tanh",
        formula: "trigo(Math.tanh,",
        type: "trigo_function",
        keyboard : ""
    },
    {
        name: "cosech",
        symbol: "cosech",
        formula: "1/trigo(Math.sinh,",
        type: "trigo_function",
        keyboard : ""
    },
    {
        name: "sech",
        symbol: "sech",
        formula: "1/trigo(Math.cosh,",
        type: "trigo_function",
        keyboard : ""
    },
    {
        name: "coth",
        symbol: "coth",
        formula: "1/trigo(Math.tanh,",
        type: "trigo_function",
        keyboard : ""
    },
    {
        name: "1",
        symbol: 1,
        formula: 1,
        type: "number",
        keyboard : "1"
    },
    {
        name: "2",
        symbol: 2,
        formula: 2,
        type: "number",
        keyboard : "2"
    },
    {
        name: "3",
        symbol: 3,
        formula: 3,
        type: "number",
        keyboard : "3"
    },
    {
        name: "4",
        symbol: 4,
        formula: 4,
        type: "number",
        keyboard : "4"
    },
    {
        name: "5",
        symbol: 5,
        formula: 5,
        type: "number",
        keyboard : "5"
    },
    {
        name: "6",
        symbol: 6,
        formula: 6,
        type: "number",
        keyboard : "6"
    },
    {
        name: "7",
        symbol: 7,
        formula: 7,
        type: "number",
        keyboard : "7"
    },
    {
        name: "8",
        symbol: 8,
        formula: 8,
        type: "number",
        keyboard : "8"
    },
    {
        name: "9",
        symbol: 9,
        formula: 9,
        type: "number",
        keyboard : "9"
    },
    {
        name: "division",
        symbol: "÷",
        formula: "/",
        type: "operator",
        keyboard : "/"
    },
    {
        name: "e",
        symbol: "e",
        formula: "Math.E",
        type: "number",
        keyboard : "e"
    },
    {
        name: "multiplication",
        symbol: "×",
        formula: "*",
        type: "operator",
        keyboard : "*"
    },
    {
        name: "factorial",
        symbol: "×!",
        formula: fact,
        type: "math_function",
        keyboard : "!"
    },
    {
        name: "exp",
        symbol: "exp",
        formula: "Math.exp",
        type: "math_function",
        keyboard : ""
    },
    {
        name: "ln",
        symbol: "ln",
        formula: "Math.log",
        type: "math_function",
        keyboard : "l"
    },
    {
        name: "log",
        symbol: "log",
        formula: "Math.log10",
        type: "math_function",
        keyboard : "g"
    },
    {
        name: "subtraction",
        symbol: "-",
        formula: "-",
        type: "operator",
        keyboard : "-"
    },
    {
        name: "power",
        symbol: "x<span>y</span>",
        formula: power,
        type: "math_function",
        keyboard : "^"
    },
    {
        name: "power10",
        symbol: "10<span>x</span>",
        formula: power,
        type: "math_function",
        keyboard : ""
    },
    {
        name: "ANS",
        symbol: "ANS",
        formula: "ans",
        type: "number",
        keyboard : ""
    },
    {
        name: "percent",
        symbol: "%",
        formula: "/100",
        type: "number",
        keyboard : "%"
    },
    {
        name: "comma",
        symbol: ".",
        formula: ".",
        type: "number",
        keyboard : "."
    },
    {
        name: "0",
        symbol: 0,
        formula: 0,
        type: "number",
        keyboard : "0"
    },
    {
        name: "calculate",
        symbol: "=",
        formula: "=",
        type: "calculate",
        keyboard : "Enter"
    },
    {
        name: "addition",
        symbol: "+",
        formula: "+",
        type: "operator",
        keyboard : "+"
    },
    {
        name: "mod",
        symbol: "mod",
        formula: "%",
        type: "operator",
        keyboard : ""
    },
    {
        name: "abs",
        symbol: "abs",
        formula: "Math.abs",
        type: "math_function",
        keyboard : ""
    },
    {
        name: "inverse",
        symbol: "1/",
        formula: "1/",
        type: "math_function",
        keyboard : ""
    },
    {
        name: "MC",
        symbol: "MC",
        formula: "",
        type: "memory_function",
        keyboard : ""
    },
    {
        name: "MR",
        symbol: "MR",
        formula: "",
        type: "memory_function",
        keyboard : ""
    },
    {
        name: "M+",
        symbol: "M+",
        formula: "",
        type: "memory_function",
        keyboard : ""
    },
    {
        name: "M-",
        symbol: "M-",
        formula: "",
        type: "memory_function",
        keyboard : ""
    },
    {
        name: "ceil",
        symbol: "ceil",
        formula: "Math.ceil",
        type: "math_function",
        keyboard : ""
    },
    {
        name: "floor",
        symbol: "floor",
        formula: "Math.floor",
        type: "math_function",
        keyboard : ""
    },
    {
        name: "invert",
        symbol: "invert",
        formula: "",
        type: "special_function",
        keyboard : ""
    }
];

// RAD and DEG
let radian = true;
// Toggle Between radian and Degrees
let radBtn = document.getElementById('rad');
let degBtn = document.getElementById('deg');

function angleToggler() {
    radBtn.classList.toggle('active');
    degBtn.classList.toggle('active');
}

function search(array, keyword) {
    let searchResult = [];
    array.forEach((element, index) => {
        if (element == keyword) searchResult.push(index);
    })

    return searchResult
}

function toggleTrigoFunctions(){
    document.getElementById('trigo_fns1').classList.toggle('trigo_inactive')
    document.getElementById('trigo_fns2').classList.toggle('trigo_inactive')
    document.getElementById('trigo_fns3').classList.toggle('trigo_inactive')
}

let trigoFunctionButton = document.getElementById('trigo_functions');
trigoFunctionButton.addEventListener('click', function () {
    toggleTrigoFunctions();
})

// Click Event Handlers
inputElement.addEventListener("click", event => {
    const target_btn = event.target;
    calculatorButtons.forEach(button => {
        if (button.name == target_btn.id) {
            calculator(button);
        }
    })
})


// Keyboard Event Listener
window.addEventListener("keydown",function (event) {
    const targetButton = event.key;
    calculatorButtons.forEach(button => {
        if(targetButton === "v") {
            toggleTrigoFunctions();
        }
        if(button.keyboard == targetButton) {
            calculator(button);
        }
    })
})

// Calculator Function
function calculator(button) {
    if (button.type === "operator") {
        data.operation.push(button.symbol);
        data.formula.push(button.formula);

    } else if (button.type === "trigo_function") {
        data.operation.push(button.symbol + "(");
        data.formula.push(button.formula);

    } else if (button.type === "number") {
        data.operation.push(button.symbol);
        data.formula.push(button.formula);

    } else if (button.type === "math_function") {

        let symbol, formula;

        if (button.name === "factorial") {
            symbol = "!";
            formula = button.formula;

            data.operation.push(symbol);
            data.formula.push(formula);

        } else if (button.name === "power") {
            symbol = "^(";
            formula = "^(";

            data.operation.push(symbol);
            data.formula.push(formula);

        } else if (button.name === "square") {
            symbol = "^(";
            formula = "^(";

            data.operation.push(symbol);
            data.formula.push(formula);

            data.operation.push("2)");
            data.formula.push("2)");

        } else if (button.name === "power10") {
            symbol = "10^(";
            formula = "10^(";

            data.operation.push(symbol);
            data.formula.push(formula);

        } else {
            symbol = button.symbol + "(";
            formula = button.formula + "(";
            data.operation.push(symbol);
            data.formula.push(formula);
        }


    } else if (button.type === "special_function") {
        let tmpArray = []
        for (let index = data.operation.length - 1; index >= 0; index--) {
            if (data.operation[index] === '+' ||
                data.operation[index] === '-' ||
                data.operation[index] === '*' ||
                data.operation[index] === '/' ||
                data.operation[index] === "(") {
                break;
            } else {
                tmpArray.unshift(data.operation.pop());
                data.formula.pop();
            }
        }

        if (data.formula.length === 0) {
            data.formula.push(0);
            // data.operation.push(0);
        }
        data.operation.push('-');
        data.formula.push('-');


        tmpArray.forEach(element => {
            data.operation.push(element)
            data.formula.push(element);
        })
    } else if (button.type === "key") {
        if (button.name === "clear") {
            data.operation = [];
            data.formula = [];
            updateOutputResult('');
        } else if (button.name === "delete") {
            data.operation.pop();
            data.formula.pop();
        } else if (button.name === "rad") {
            radian = true;
            angleToggler();
        } else if (button.name === "deg") {
            radian = false;
            angleToggler();
        }


    } else if (button.type === "calculate") {
        getResult();
        updateOutputResult(result);
    } else if (button.type = "memory_function") {

        if (button.name === "MC") {
            // Clear the Local Storage Memory
            localStorage.setItem("storedValue", "[0]");

        } else if (button.name === "MR") {
            //Read the Local Storage Memory and Evaluate
            value = JSON.parse(localStorage.getItem("storedValue"));
            let calculatedStoredValue = eval(value.join(''))

            // Store the result again in the Local Memory
            localStorage.setItem("storedValue", `[${calculatedStoredValue}]`);

            // Update the Result on the resultText
            updateOutputResult(calculatedStoredValue);

        } else if (button.name === "M+") {
            // Check if a valid result is there
            if (typeof (result) === "number") {
                let storedArray = JSON.parse(localStorage.getItem("storedValue"));

                // Push + sign
                storedArray.push("+");
                storedArray.push(result);

                localStorage.setItem("storedValue", JSON.stringify(storedArray))
            }

        } else if (button.name === "M-") {

            // Check if a valid result is there
            if (typeof (result) === "number") {
                let storedArray = JSON.parse(localStorage.getItem("storedValue"));

                // Push - sign
                storedArray.push("-");
                storedArray.push(result);

                localStorage.setItem("storedValue", JSON.stringify(storedArray))
            }
        }
    }

    updateOutputOperation(data.operation.join(''));
}

// Show Expression on top
function updateOutputOperation(operation) {
    outputOperatorElement.value = operation;
}

// Show Result in the Result Tab
function updateOutputResult(result) {
    OutputResultElement.value = result;
}

// Get The Result of the Expression
function getResult() {
    // Search for Factorials in the Expression
    // Return array of the positions of the Factorial
    let factorialSearchResult = search(data.formula, fact);

    // Convert the Array to String for Eval Function
    formulaStr = data.formula.join('');

    // Replace the Factorial with a Proper Factorial Function
    const numbers = factorialNumberGetter(data.formula, factorialSearchResult);
    numbers.forEach(factorial => {
        formulaStr = formulaStr.replace(factorial.toReplace, factorial.replacement);
    });

    // Replace ^(power) with ** and "--" to "+"
    newFormulaStr = formulaStr.replaceAll("^", "**");
    newFormulaStr = newFormulaStr.replaceAll("--", "+");
    
    try {
        result = eval(newFormulaStr);

        // If the Answer is in Float then round up to 4 decimal places
        if (result % 1 != 0) {
            result = parseFloat(result).toFixed(4);
        }
    } catch (error) {
        if (error instanceof SyntaxError) {
            result = "Syntax Error!";
            updateOutputResult(result)
            return
        }
    }

}


function trigo(callback, angle) {
    if (!radian) {
        // Convert Degrees to Radian
        angle = angle * Math.PI / 180;
    }
    return callback(angle);
}

function inverseTrigo(callback, value) {
    let angle = callback(value);

    if (!radian) {
        angle = angle * 180 / Math.PI
    }

    return angle;
}

function factorialNumberGetter(formula, factorialSearchResult) {
    let numbers = [];
    let factorialSequence = 0;

    factorialSearchResult.forEach(factorialIndex => {
        let number = [];

        let next_index = factorialIndex + 1;
        let next_input = formula[next_index];

        if (next_input == fact) {
            factorialSequence++;
            return;
        }

        // If there was a factorial sequence, we need to get
        // The Index of the Very First Factorial Function
        let firstFactorialSequence = factorialIndex - factorialSequence;

        // Then to Get the Number Right before it;

        let previousIndex = firstFactorialSequence - 1;
        let parenthesisCount = 0;

        while (previousIndex >= 0) {
            
            if (formula[previousIndex] == "(") parenthesisCount--;
            if (formula[previousIndex] == ")") parenthesisCount++;

            let is_operator = false;
            operators.forEach(operator => {
                if (formula[previousIndex] == operator) is_operator = true;
            })

            if (is_operator && parenthesisCount == 0) { break; }

            // Push the Element on this to Index to Start of the Number Array
            number.unshift(formula[previousIndex]);
            previousIndex--;
        }

        // Convert Number array to string
        let numberStr = number.join('');

        // define variables
        const factorial = "factorial(", closeParenthesis = ")";
        
        // Times factorial occurs
        let times = factorialSequence + 1;
        
        // The Sub String to Replace
        let toReplace = numberStr + fact.repeat(times);
        
        // The Replacement of the SubString
        let replacement = factorial.repeat(times) + numberStr + closeParenthesis.repeat(times);

        numbers.push({
            toReplace: toReplace,
            replacement: replacement
        })
        factorialSequence = 0;
    })
    return numbers;
}


//Factorial Function
function factorial(num) {
    // Factorial of 0 and 1 is 1
    if (num === 0 || num === 1) return 1;
    let result = 1;
    for (let i = 1; i <= num; i++) {
        result *= i;
        // Check for Infinity Value of Factorial
        if (result === Infinity) {
            return Infinity
        }
    }
    return result;
}
